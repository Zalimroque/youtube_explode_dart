// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'fragment.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Fragment _$FragmentFromJson(Map<String, dynamic> json) => Fragment(
      json['path'] as String,
    );

Map<String, dynamic> _$FragmentToJson(Fragment instance) => <String, dynamic>{
      'path': instance.path,
    };
