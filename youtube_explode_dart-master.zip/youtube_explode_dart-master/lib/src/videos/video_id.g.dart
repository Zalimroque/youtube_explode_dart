// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'video_id.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$VideoIdImpl _$$VideoIdImplFromJson(Map<String, dynamic> json) =>
    _$VideoIdImpl(
      json['value'] as String,
    );

Map<String, dynamic> _$$VideoIdImplToJson(_$VideoIdImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };
