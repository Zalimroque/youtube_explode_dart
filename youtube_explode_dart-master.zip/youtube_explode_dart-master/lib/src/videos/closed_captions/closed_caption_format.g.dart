// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'closed_caption_format.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ClosedCaptionFormat _$ClosedCaptionFormatFromJson(Map<String, dynamic> json) =>
    ClosedCaptionFormat(
      json['formatCode'] as String,
    );

Map<String, dynamic> _$ClosedCaptionFormatToJson(
        ClosedCaptionFormat instance) =>
    <String, dynamic>{
      'formatCode': instance.formatCode,
    };
