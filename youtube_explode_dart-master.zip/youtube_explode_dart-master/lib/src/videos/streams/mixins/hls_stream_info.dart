import '../../../../youtube_explode_dart.dart';

mixin HlsStreamInfo on StreamInfo {
  /// The tag of the audio stream related to this stream.
  int? get audioItag => null;
}
