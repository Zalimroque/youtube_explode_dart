// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'framerate.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FramerateImpl _$$FramerateImplFromJson(Map<String, dynamic> json) =>
    _$FramerateImpl(
      json['framesPerSecond'] as num,
    );

Map<String, dynamic> _$$FramerateImplToJson(_$FramerateImpl instance) =>
    <String, dynamic>{
      'framesPerSecond': instance.framesPerSecond,
    };
