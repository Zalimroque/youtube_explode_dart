// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'stream_container.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$StreamContainerImpl _$$StreamContainerImplFromJson(
        Map<String, dynamic> json) =>
    _$StreamContainerImpl(
      json['name'] as String,
    );

Map<String, dynamic> _$$StreamContainerImplToJson(
        _$StreamContainerImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
    };
