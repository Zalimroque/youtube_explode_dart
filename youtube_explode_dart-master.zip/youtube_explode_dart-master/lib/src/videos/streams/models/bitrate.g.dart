// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'bitrate.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BitrateImpl _$$BitrateImplFromJson(Map<String, dynamic> json) =>
    _$BitrateImpl(
      (json['bitsPerSecond'] as num).toInt(),
    );

Map<String, dynamic> _$$BitrateImplToJson(_$BitrateImpl instance) =>
    <String, dynamic>{
      'bitsPerSecond': instance.bitsPerSecond,
    };
