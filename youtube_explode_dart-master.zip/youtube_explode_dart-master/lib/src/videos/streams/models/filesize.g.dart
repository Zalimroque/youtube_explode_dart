// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'filesize.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FileSizeImpl _$$FileSizeImplFromJson(Map<String, dynamic> json) =>
    _$FileSizeImpl(
      (json['totalBytes'] as num).toInt(),
    );

Map<String, dynamic> _$$FileSizeImplToJson(_$FileSizeImpl instance) =>
    <String, dynamic>{
      'totalBytes': instance.totalBytes,
    };
