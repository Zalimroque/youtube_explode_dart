// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, require_trailing_commas

part of 'audio_track.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AudioTrackImpl _$$AudioTrackImplFromJson(Map<String, dynamic> json) =>
    _$AudioTrackImpl(
      displayName: json['displayName'] as String,
      id: json['id'] as String,
      audioIsDefault: json['audioIsDefault'] as bool,
    );

Map<String, dynamic> _$$AudioTrackImplToJson(_$AudioTrackImpl instance) =>
    <String, dynamic>{
      'displayName': instance.displayName,
      'id': instance.id,
      'audioIsDefault': instance.audioIsDefault,
    };
