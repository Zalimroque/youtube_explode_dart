
The files in this directory are derived from the `ensemble/parsejs_null_safety` project, which is licensed under the BSD-3-Clause License.

Small modifications have been made to the original files to better integrate them into this project.

## Original Project Information:
- **Project Name**: jsparser
- **Original Author(s)**: EnsembleUI, Khurram Mahmood (original - Anurag Vohra)
- **Source Repository**: https://github.com/EnsembleUI/ensemble/tree/main/modules/parsejs_null_safety

## License Information:
The original files are licensed under the BSD 3-Clause License, see the [LICENSE](LICENSE-original).