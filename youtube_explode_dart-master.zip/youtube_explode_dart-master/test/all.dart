import 'channel_about_test.dart' as i0;
import 'channel_id_test.dart' as i1;
import 'channel_test.dart' as i2;
import 'closed_caption_test.dart' as i3;
import 'comments_client_test.dart' as i4;
import 'playlist_id_test.dart' as i5;
import 'playlist_test.dart' as i6;
import 'search_test.dart' as i7;
import 'streams_test.dart' as i8;
import 'username_test.dart' as i9;
import 'video_id_test.dart' as i10;
import 'video_test.dart' as i11;

void main() {
  i0.main();
  i1.main();
  i2.main();
  i3.main();
  i4.main();
  i5.main();
  i6.main();
  i7.main();
  i8.main();
  i9.main();
  i10.main();
  i11.main();
}
