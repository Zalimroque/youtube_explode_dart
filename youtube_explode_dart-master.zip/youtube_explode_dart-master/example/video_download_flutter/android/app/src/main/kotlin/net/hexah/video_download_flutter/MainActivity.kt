package net.hexah.video_download_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {}
